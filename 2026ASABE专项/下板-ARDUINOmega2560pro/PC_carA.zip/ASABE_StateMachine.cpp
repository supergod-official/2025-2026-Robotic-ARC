#include "ASABE_StateMachine.h"


const uint8_t TASK_QUEUE_SIZE = 20;
StateTask taskQueue[TASK_QUEUE_SIZE];
uint8_t taskCount = 0;
uint8_t currentTaskIndex = 0;
bool taskRunning = false;
StateTask currentTask;
unsigned long inTargetBandStartMs = 0;
unsigned long stateStartMs = 0;
const unsigned long IN_TARGET_HOLD_MS = 100UL;
// 在全局变量区域添加
long long lastSendTime = 0,bootStartTime = 0;
bool bootTimeInitialized = false;
PCencoder qm;
PCencoder pm;
PCencoder dm;
PCencoder bm;

ExpectedVoltage expectedVoltage = {0.0f, 0.0f, 0.0f};
SensorData sensorData = {
    100.0f,   // DistanceF
    0.0f,     // DistanceB

    -90.0f,   // fAngle
    0.0f      // fGyro
};
pidControll car_pid = {
    0.9f,     // kp
    0.0f,     // ki
    0.1f,     // kd
    0.8f,     // kp_w
    0.0f,     // ki_w
    0.06f,    // kd_w
    0.0f, // pulse_to_distance
    0.0f,    // deadvoltage
    0.0f     // integralmax
};

pidControll m_pid = {
    2.0f,     // kp         5
    5.0f,     // ki        5
    0.0f,     // kd
    0.0f,     // kp_w
    0.0f,     // ki_w
    0.0f,     // kd_w
    0.02445f, // pulse_to_distance
    20.0f,    // deadvoltage
    35.0f     // integralmax 15
};
/*
struct pidControll {
    float kp;
    float ki;
    float kd;
    float kp_w;
    float ki_w;
    float kd_w;
    float integral;
    float integral_w;
    float integralmax;
    float integralmax_w;
    float pulse_to_distance;
};
struct StateTask {
    ActionType type;
    float targetDistance;
    float targetAngle;
    float distanceTolerance;
    float angleTolerance;
    unsigned long minDuration;
};


*/
StateTask aheadTask = {ACTION_MOVE_TO_DISTANCE, 10.0f, -90.0f, 3.0f, 5.0f, 1000UL,1};
StateTask _aheadTask = {ACTION_MOVE_TO_DISTANCE, 55.72f, -90.0f, 3.0f, 5.0f, 1000UL,1}; // 18*2.54 + 10 = 45.72+10
StateTask left1Task = {ACTION_MOVE_TO_DISTANCE, 118.0f, 0.0f, 3.0f, 5.0f, 1000UL,0};
StateTask left2Task = {ACTION_MOVE_TO_DISTANCE, 44.72f, 0.0f, 3.0f, 5.0f, 1000UL,0}; // 14*2.54 + 10 = 35.72+10 = 46.72
StateTask left3Task = {ACTION_MOVE_TO_DISTANCE, 10.0f, 0.0f, 3.0f, 5.0f, 1000UL,0};
StateTask backTask = {ACTION_MOVE_TO_DISTANCE, 10.0f, 90.0f, 3.0f, 5.0f, 1000UL,1};
StateTask turnAhead = {ACTION_TURN_TO_ANGLE, 0.0f, -90.0f, 5.0f, 3.0f, 100UL,0};
StateTask turnBack = {ACTION_TURN_TO_ANGLE, 0.0f, 90.0f, 5.0f, 3.0f, 100UL,0};
StateTask turnLeft = {ACTION_TURN_TO_ANGLE, 0.0f, 0.0f, 5.0f, 3.0f, 100UL,0};
StateTask stopTask = {ACTION_STOP, 0.0f, 0.0f, 0.0f, 0.0f, 0UL,0};

bool startNextTask() {
    if (currentTaskIndex >= taskCount) {
        taskRunning = false;
        return false;
    }

    currentTask = taskQueue[currentTaskIndex++];
    taskRunning = true;
    inTargetBandStartMs = 0;
    stateStartMs = millis();
    return true;
}

void enqueueTask(const StateTask& task) {
    if (taskCount < TASK_QUEUE_SIZE) {
        taskQueue[taskCount++] = task;
    }
}

void buildDefaultTaskQueue() {
    enqueueTask(aheadTask);

    enqueueTask(turnLeft);
    enqueueTask(left1Task);

    enqueueTask(turnBack);
    enqueueTask(backTask);

    enqueueTask(turnLeft);
    enqueueTask(left2Task);

    enqueueTask(turnAhead);
    enqueueTask(_aheadTask);

    enqueueTask(turnLeft);
    enqueueTask(left3Task);

    enqueueTask(turnBack);
    enqueueTask(backTask);

    enqueueTask(stopTask);
}

void timerCallback() {
    qm.updateSpeed0();
    pm.updateSpeed0();
    dm.updateSpeed0();
    bm.updateSpeed0();
}

void Car_updateSpeedInloop() {
    qm.updateSpeedInloop();
    pm.updateSpeedInloop();
    dm.updateSpeedInloop();
    bm.updateSpeedInloop();
}

void Car_brake() {
    qm.brake();
    pm.brake();
    dm.brake();
    bm.brake();
}

void Car_clearIngral() {
    qm.clearIntegral();
    pm.clearIntegral();
    dm.clearIntegral();
    bm.clearIntegral();
}

double Speedv_contorll(float distanceToGo) {
    double speedcar = (pm.readspeed() + dm.readspeed() + qm.readspeed() + bm.readspeed()) / 4.0f;
    return car_pid.kp * distanceToGo - car_pid.kd * speedcar + 2.0;
}

double SpeedW_contorll(float angleToGo) {
    return car_pid.kp_w * angleToGo - car_pid.kd_w * sensorData.fGyro;
}

void Car_distanceContorll(float distancetogo, float mincontrolldistance, float errordistance) {
    float angleToGo = sensorData.fAngle - currentTask.targetAngle;

    if (distancetogo > mincontrolldistance) {
        expectedVoltage.speedX = 20;
    } else if (distancetogo < -mincontrolldistance) {
        expectedVoltage.speedX = -20;
    } else if (fabs(distancetogo) < errordistance) {
        if (fabs(angleToGo) < 5) {
            Car_brake();
            Car_clearIngral();
            return;
        }
        expectedVoltage.speedX = 0;
    } else {
        expectedVoltage.speedX = Speedv_contorll(distancetogo);
    }


    expectedVoltage.speedZ = SpeedW_contorll(angleToGo);
    qm.setspeed(expectedVoltage.speedX + expectedVoltage.speedZ);
    pm.setspeed(expectedVoltage.speedX - expectedVoltage.speedZ);
    dm.setspeed(expectedVoltage.speedX + expectedVoltage.speedZ);
    bm.setspeed(expectedVoltage.speedX - expectedVoltage.speedZ);
}

void Car_angleContorll(float angletogo, float mincontrollangle, float errorangle) {
    if (angletogo > mincontrollangle) {
        expectedVoltage.speedZ = 90;
    } else if (angletogo < -mincontrollangle) {
        expectedVoltage.speedZ = -90;
    } else if (fabs(angletogo) < errorangle) {
        Car_brake();
        Car_clearIngral();
        return;
    } else {
        expectedVoltage.speedZ = SpeedW_contorll(angletogo);
    }

    expectedVoltage.speedX = 0;
    qm.setspeed(expectedVoltage.speedX + expectedVoltage.speedZ);
    pm.setspeed(expectedVoltage.speedX - expectedVoltage.speedZ);
    dm.setspeed(expectedVoltage.speedX + expectedVoltage.speedZ);
    bm.setspeed(expectedVoltage.speedX - expectedVoltage.speedZ);
}



void sendUartStatus() {
    if (!bootTimeInitialized) {
        lastSendTime = millis();
        bootStartTime = millis();
        bootTimeInitialized = true;
        return;
    }
    // 启动后前2秒不发送


    if (millis() - lastSendTime >= 50) {
        lastSendTime = millis();
        uint8_t buffer[6];
        float carSpeed = (pm.readspeed() + dm.readspeed() + qm.readspeed() + bm.readspeed()) / 4.0f;
        
        // 判断是否在直线状态：当前任务是移动且角度接近目标角度
        bool isStraight = taskRunning && 
                        currentTask.workSign == 1 ;
                        
        Serial.print("cartype:");
        Serial.println(isStraight);
        buffer[0] = isStraight;
        memcpy(&buffer[1], &carSpeed, 4);
        buffer[5] = 0xAA;
        
        Serial2.write(buffer, 6);
    }
}
void updateStateMachine() {
    if (!taskRunning) {
        if (!startNextTask()) {
            Car_brake();
            return;
        }
    }

    switch (currentTask.type) {
        case ACTION_MOVE_TO_DISTANCE: {
            float distanceToGo = sensorData.DistanceF - currentTask.targetDistance;
            float carspeed = (pm.readspeed() + dm.readspeed() + qm.readspeed() + bm.readspeed()) / 4.0f;

            Car_distanceContorll(distanceToGo, 20, 2);

            bool inTargetBand = fabs(distanceToGo) < currentTask.distanceTolerance;
            if (inTargetBand) {
                if (inTargetBandStartMs == 0) {
                    inTargetBandStartMs = millis();
                }
            } else {
                inTargetBandStartMs = 0;
            }

            if (inTargetBandStartMs != 0 &&
                (millis() - inTargetBandStartMs) >= IN_TARGET_HOLD_MS &&
                millis() - stateStartMs > currentTask.minDuration &&
                fabs(carspeed) < 5) {
                taskRunning = false;
            }
            break;
        }

        case ACTION_TURN_TO_ANGLE: {
            float angleToGo = sensorData.fAngle - currentTask.targetAngle;
            float carspeedw = (qm.readspeed() - pm.readspeed() + dm.readspeed() - bm.readspeed()) / 4.0f;

            Car_angleContorll(angleToGo, 30, 2);

            bool inTargetBand = fabs(angleToGo) < currentTask.angleTolerance;
            if (inTargetBand) {
                if (inTargetBandStartMs == 0) {
                    inTargetBandStartMs = millis();
                }
            } else {
                inTargetBandStartMs = 0;
            }

            if (inTargetBandStartMs != 0 &&
                (millis() - inTargetBandStartMs) >= IN_TARGET_HOLD_MS &&
                millis() - stateStartMs > currentTask.minDuration &&
                fabs(carspeedw) < 5) {
                taskRunning = false;
            }
            break;
        }

        case ACTION_STOP: {
            Car_brake();
            Car_clearIngral();
            taskRunning = false;
            break;
        }
    }
}
