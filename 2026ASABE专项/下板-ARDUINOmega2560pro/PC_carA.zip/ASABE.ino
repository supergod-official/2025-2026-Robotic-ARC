#include "PC_carA.h"
#include "PCencoder_.h"
#include "ASABE_StateMachine.h"
#include <MsTimer2.h> 
#include <NewPing.h>
#include <REG.h> 
#include <wit_c_sdk.h>
#include <Wire.h>
#include <SparkFun_VL53L1X.h>
#include <math.h>

#define useULtra_true 0
#define useVl53_true 1
/*--------------------------------VL53L1X-------------------------------__*/

#define SHUTDOWN_PIN_F 49
#define INT_PIN_F 48
#define SHUTDOWN_PIN_B 50
#define INT_PIN_B 51
#define VL53L1X_ADDR_1 0x54
#define VL53L1X_ADDR_2 0x56
SFEVL53L1X distanceSensor1;
SFEVL53L1X distanceSensor2;
/*--------------------------------HWT101--------------------------------__*/
//闄€铻轰华鍙橀噺
#define ACC_UPDATE		0x01 //s_cDataUpdate
#define GYRO_UPDATE		0x02 //s_cDataUpdate
#define ANGLE_UPDATE	0x04 //s_cDataUpdate
#define MAG_UPDATE		0x08 //s_cDataUpdate
#define READ_UPDATE		0x80 //s_cDataUpdate
static volatile char s_cDataUpdate = 0;


//瀹氫箟闈欐€佸嚱鏁?
static void HWT101_read();
static void VL53L1X_read();
static void SensorUartSend(uint8_t *p_data, uint32_t uiSize);
static void SensorDataUpdata(uint32_t uiReg, uint32_t uiRegNum);
static void Delayms(uint16_t ucMs);









#if useULtra_true
/*--------------------------------HC_SR04----------------------------------*/
#define TRIGGER_PINf  A2  // Arduino pin tied to trigger pin on the ultrasonic sensor.
#define ECHO_PINf     A3  // Arduino pin tied to echo pin on the ultrasonic sensor.
#define MAX_DISTANCEf 50.0f // Maximum distance we want to ping for (in centimeters). Maximum sensor distance is rated at 400-500cm.

#define TRIGGER_PINl  A9  
#define ECHO_PINl     A8 
#define MAX_DISTANCEl 15.0f

#define TRIGGER_PINr  A4  
#define ECHO_PINr     A5  
#define MAX_DISTANCEr 15.0f

unsigned long US_prMicros = 0;

#define US_Interval   20000                    
#define US_TIME_TO_DISTANCE  0.01717  


NewPing sonarF(TRIGGER_PINf, ECHO_PINf, MAX_DISTANCEf); 
NewPing sonarL(TRIGGER_PINl, ECHO_PINl, MAX_DISTANCEl);
NewPing sonarR(TRIGGER_PINr, ECHO_PINr, MAX_DISTANCEr);

void US_Read(uint8_t currentState) {
    if (micros() - US_prMicros >= US_Interval) {
        US_prMicros = micros();
        switch (currentState) {
            case 0:
                sensorData.DistanceL = sonarL.ping() * US_TIME_TO_DISTANCE;
                sensorData.DistanceR = sonarR.ping() * US_TIME_TO_DISTANCE;
                if (sensorData.DistanceR < 0.1 && -0.1 < sensorData.DistanceR) 
                    sensorData.DistanceR = MAX_DISTANCEr;
                if (sensorData.DistanceL < 0.1 && -0.1 < sensorData.DistanceL) 
                    sensorData.DistanceL = MAX_DISTANCEl;
                break;
            case 1:
                sensorData.DistanceF = sonarF.ping() * US_TIME_TO_DISTANCE;
                sensorData.DistanceL = sonarL.ping() * US_TIME_TO_DISTANCE;
                sensorData.DistanceR = sonarR.ping() * US_TIME_TO_DISTANCE;

                if (sensorData.DistanceF < 0.1 && -0.1 < sensorData.DistanceF ) 
                    sensorData.DistanceF = MAX_DISTANCEf;
                if (sensorData.DistanceL < 0.1 && -0.1 < sensorData.DistanceL) 
                    sensorData.DistanceL = MAX_DISTANCEl;
                if (sensorData.DistanceR < 0.1 && -0.1 < sensorData.DistanceR) 
                    sensorData.DistanceR = MAX_DISTANCEr;
                break;
            case 2:
                sensorData.DistanceR = MAX_DISTANCEr;
                sensorData.DistanceL = MAX_DISTANCEl;
                sensorData.DistanceF = MAX_DISTANCEf;
                break;
            default:
                break;
        }
    }
    //Serial.println(sensorData.DistanceF);
    //Serial.println(sensorData.DistanceR);
}
#else 
    //"None"
#endif


void setup() {


    Wire.begin();
    Wire.setClock(400000); // Set I2C frequency to 400kHz
    Serial.begin(115200); // Open serial monitor at 115200 baud to see ping results.
    Serial1.begin(115200);
    Serial2.begin(115200);

    if(!qm.attach(DIR_PIN_QM_1, DIR_PIN_QM_2, PWM_PIN_QM, PC_PIN_QM_1, PC_PIN_QM_2, 0.02)){Serial.print("bad attach qm"); while(1);}
    qm.setpid(m_pid.kp, m_pid.ki, m_pid.kd, m_pid.pulse_to_distance,m_pid.deadvoltage,m_pid.integralmax);   

    if(!pm.attach(DIR_PIN_PM_1, DIR_PIN_PM_2, PWM_PIN_PM, PC_PIN_PM_1, PC_PIN_PM_2, 0.02)){Serial.print("bad attach pm");while(1);}
    pm.setpid(m_pid.kp, m_pid.ki, m_pid.kd, m_pid.pulse_to_distance,m_pid.deadvoltage,m_pid.integralmax);

    if(!dm.attach(DIR_PIN_DM_1, DIR_PIN_DM_2, PWM_PIN_DM, PC_PIN_DM_1, PC_PIN_DM_2, 0.02)){Serial.print("bad attach dm");while(1);}
    dm.setpid(m_pid.kp, m_pid.ki, m_pid.kd, m_pid.pulse_to_distance,m_pid.deadvoltage,m_pid.integralmax);

    if(!bm.attach(DIR_PIN_BM_1, DIR_PIN_BM_2, PWM_PIN_BM, PC_PIN_BM_1, PC_PIN_BM_2, 0.02)){Serial.print("bad attach bm");while(1);}
    bm.setpid(m_pid.kp, m_pid.ki, m_pid.kd, m_pid.pulse_to_distance,m_pid.deadvoltage,m_pid.integralmax);
    
    //tuoluoyi---------------------------------------------------------
    WitInit(WIT_PROTOCOL_NORMAL, 0x50);
    WitSerialWriteRegister(SensorUartSend);
    WitRegisterCallBack(SensorDataUpdata);
    WitDelayMsRegister(Delayms);
    WitSetUartBaud(WIT_BAUD_115200);
    delay(300);
    WitSetYAW(0xC000); //  12*16**3/16**4 * 360= 270 -> -90 C000
    delay(300);
    WitSetOutputRate(RRATE_50HZ);
    delay(300);
    
    // MT---------------------------------------------------------
    // Timer2 
    MsTimer2::set(0.02*1000, timerCallback);
    MsTimer2::start();
    // Timer3 
    PCencoder::_setTimer3();
    //激光-----------------------------------------------------------
    //IN
    // 1) Init the sensor whose XSHUT is always high (the D3-controlled sensor is kept LOW)

#if useVl53_true
    pinMode(SHUTDOWN_PIN_F, OUTPUT);
    pinMode(SHUTDOWN_PIN_B, OUTPUT);
    pinMode(INT_PIN_F,INPUT);
    pinMode(INT_PIN_B,INPUT);

    digitalWrite(SHUTDOWN_PIN_F, HIGH); 
    digitalWrite(SHUTDOWN_PIN_B, LOW); 

    if (distanceSensor1.begin() != 0) {
    Serial.println("Sensor1 failed to begin. Check I2C wiring and D3 XSHUT state. Freezing...");
    while (1);
    }
    Serial.println("Sensor1 ranging started.");
    distanceSensor1.setI2CAddress(VL53L1X_ADDR_1);
    delay(10);
    distanceSensor1.setTimingBudgetInMs(33); // 
    distanceSensor1.setIntermeasurementPeriod(40); 



    delay(50);
    digitalWrite(SHUTDOWN_PIN_F, HIGH); 
    digitalWrite(SHUTDOWN_PIN_B, HIGH);     
    if (distanceSensor2.begin() != 0) {
    Serial.println("Sensor2 failed to begin. D3 may not be controlling XSHUT correctly. Freezing...");
    while (1);
    }
    Serial.println("Sensor2 ranging started.");
    distanceSensor2.setI2CAddress(VL53L1X_ADDR_2);
    delay(10);
    distanceSensor2.setTimingBudgetInMs(33); // 20ms ??????????
    distanceSensor2.setIntermeasurementPeriod(40); 


    distanceSensor1.startRanging();
    distanceSensor2.startRanging();
    
#else 
#endif
    buildDefaultTaskQueue(); // Build the task queue for the state machine
    stateStartMs = millis();
    delay(30);
}
int32_t a = 0;
int32_t pre_ = 0;
int32_t now_ = 0;
void loop() {

    HWT101_read();
    VL53L1X_read();
    Car_updateSpeedInloop();
    updateStateMachine();
    sendUartStatus();

    a++;
    if(a>=1000){
      a=0;
      now_ = millis();
      //Serial.println();
      Serial.print("delta:");
      Serial.println((now_-pre_)/1000.0);
      pre_ = now_;
    }
}

/*--------------------------------HWT101CT 闄€铻轰华浼犳劅鍣?---------------------------------*/
void HWT101_read(){
  while (Serial1.available())
  {
    //Serial.println("1");
    WitSerialDataIn(Serial1.read());
  }
  if (s_cDataUpdate) 
  {
    sensorData.fGyro = sReg[57] / 32768.0f * 2000.0f; 
    sensorData.fAngle = sReg[63] / 32768.0f * 180.0f; 
    if (s_cDataUpdate & GYRO_UPDATE)
    {
      /*Serial.print("GyroZ: ");
      Serial.print(fGyro, 1);
      Serial.print("\r\n");
      s_cDataUpdate &= ~GYRO_UPDATE;*/
    }
    if (s_cDataUpdate & ANGLE_UPDATE)
    {
      /*Serial.print("AngleZ: ");
      Serial.print(fAngle, 3);
      Serial.print("\r\n");
      s_cDataUpdate &= ~ANGLE_UPDATE;*/
    }
    s_cDataUpdate = 0;
  }
}
static void SensorUartSend(uint8_t *p_data, uint32_t uiSize)
{
  //杩欓噷瑙勫畾浜嗗線Arduino鐨勪覆鍙?鍙戦€佹暟鎹紝涔熷彲浠ユ敼涓哄叾浠栫殑纭欢涓插彛
  Serial1.write(p_data, uiSize);
  //鎵€鏈夊彂閫佺紦瀛樹腑鐨勬暟鎹叏閮ㄥ彂閫佸嚭鍘诲悗锛屼紶鎰熷櫒鎵嶄細鎵ц鍚庣画鐨勬搷浣?
  Serial1.flush();
}
static void SensorDataUpdata(uint32_t uiReg, uint32_t uiRegNum)
{ 
  int i;
  //杩欓噷涔嬫墍浠ヨ寰幆鏄洜涓?
  //浼犲叆鍑芥暟鐨剈iReg涓€鑸兘鏄疉X锛孏X锛孯oll鎵€浠ラ渶瑕佸惊鐜竴涓嬬‘瀹氭槸鍚﹀瓨鍦℅Z鍜孻aw
  for (i = 0; i < uiRegNum; i++)
  {
    switch (uiReg)
    {
      case GZ: //濡傛灉鏄痁杞磋閫熷害锛孏Z瀹氫箟涓?x39锛堝湪REG.h鏂囦欢涓級
        s_cDataUpdate |= GYRO_UPDATE; //鎶妔_cDataUpdate鍙橀噺鐨勭浜屼綅缃?
        break;
      case Yaw: //濡傛灉鏄痁杞磋搴︼紝Yaw瀹氫箟涓?x3f
        s_cDataUpdate |= ANGLE_UPDATE; //鎶妔_cDataUpdate鍙橀噺鐨勭涓変綅缃?
        break;
      default: //濡傛灉閮戒笉鏄?
        s_cDataUpdate |= READ_UPDATE; //鎶妔_cDataUpdate鍙橀噺鐨勭鍏綅缃?
        break;
    }
    uiReg++;
  }
}


static void Delayms(uint16_t ucMs)
{
  delay(ucMs);

}
// VL53L1X婵€鍏夋祴璺濅紶鎰熷櫒
void VL53L1X_read(){

  if (digitalRead(INT_PIN_F) == HIGH ){
    if (distanceSensor1.checkForDataReady()){
    sensorData.DistanceF=distanceSensor1.getDistance()/10.0;
    distanceSensor1.clearInterrupt();
    //Serial.print("0x00:");
    //Serial.println(sensorData.DistanceF);
    }
  }
  if(digitalRead(INT_PIN_B) == HIGH ){
    if (distanceSensor2.checkForDataReady()){
    sensorData.DistanceB = distanceSensor2.getDistance()/10.0; 
    distanceSensor2.clearInterrupt();
    //Serial.print("0x01:");
    //.Serial.println(sensorData.DistanceB);
    }
  }
}

