from pyb import UART
import sensor, image, time, ustruct

#clock = time.clock()
black = (0, 30, -58, 8, -12, 18)     # LAB阈值，配合RGB565使用
red = (0, 95, 15, 127, 15, 127)
purple = (0, 77, -24, 17, -38, -1)

_d=60     #从上到下  距离                              # 直线置信度阈值
d=120      #画面的大小
w=60
num_blocks = 6       #画面分块
r=20       #个分块的大小
roi1 = [(0, _*r, 320, 20)for _ in range(num_blocks)]             # 红色感兴趣区域  中下

# OpenMV: UART3 -> P4(TX) / P5(RX)
uart = UART(3, 115200)
uart.init(115200, bits=8, parity=None, stop=1)

def outuart(x, a, flag):
    global uart
    data = ustruct.pack("<hhbb",
                   int(x * 10),      # up sample by 1
                   int(a * 10),      # up sample by 4
                   int(_f+flag),        # 红线标志
                   0x5B)
    if flag==1:
        uart.write(data)
        time.sleep_us(1)
        uart.write(data)
    else : uart.write(data)

# ===== 相机初始化 =====
sensor.reset()
sensor.set_vflip(False)
sensor.set_hmirror(False)
sensor.set_framesize(sensor.QVGA)
sensor.set_pixformat(sensor.RGB565)
sensor.skip_frames(time=2000)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
#sensor.set_auto_exposure(False)

sensor.set_windowing(0, _d, 320, 130)
#sensor.set_contrast(3)  #设置对比度，范围-3~3
red_detected = False
move_x = 0
move_turn = 0
line_point = [0, 0, 0, 0, 0, 0, 0, 0]
line_area = [[0, 0, 0, 0] for _ in range(num_blocks)]
line_none = 0
stop_count = 0
midpoint = 160
m = 0

regions = [
       (0, 0, 320, w , 120),    # 上区域
       (0, 60, 320, w , 120)  # 上区域


]

while True:
    #clock.tick()
    # 捕获原始彩色图像-灰色图
    color_img = sensor.snapshot()
    gray_img=color_img.copy().to_grayscale()


    #第一张灰度图   #分别二值化

    for i, region in enumerate(regions):
            x, y, w, h ,f = region
            roi_img = gray_img.copy(roi=(x, y, w, h))
            top_hist = roi_img.get_histogram()
            top_th = top_hist.get_threshold().value()
            print("第",i,"z",top_th)
            roi_img.binary([(0, min(f,top_th))])
            gray_img.draw_image(roi_img, x, y)

    #第二张图
    blobs_ = color_img.find_blobs([red], roi=roi1[0], x_stride=5, y_stride=5, pixels_threshold=50)
    _blobs = color_img.find_blobs([red], roi=(0,90,320,40),x_stride=5, y_stride=3, pixels_threshold=25)
    color_img.binary([red])

    #两张图合并
    color_img.add(gray_img)




    # 在彩色图像上绘制叠加结果用于显示

    #color_img.draw_image(gray_img, 0, 0)

    # 红色检测（在原始彩色图像上进行）
    if blobs_:
        _f=10;
    else :
        _f=0


    if _blobs and not red_detected:
        flag = 1
        red_detected = True
    elif not _blobs and red_detected:
        red_detected = False
        flag = 0
    else:
        flag = 0



    # 在叠加后的图像上寻找黑线
    for n in range(0, num_blocks):
        blobs = color_img.find_blobs([(50, 255)], roi=(0, n*r, 320, r),
                                       x_stride=30, y_stride=10, pixels_threshold=300)

        if blobs:
            blob = max(blobs, key=lambda b: b.pixels())
            color_img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
            line_area[n] = blob.rect()
            line_point[n] = blob.cx() - midpoint

            #if midpoint * 1 < blob.w() < midpoint * 1.75:
            #    line_point[n] = line_point[n] * 2
        else:
            line_area[n] = -1
            line_point[n] = -500

    line_none = 0

    # 处理寻迹逻辑
    for n in range(num_blocks-1, -1, -1):
        if line_point[n] > -500:
            move_x = line_point[n]
            move_turn = line_point[n]
            break

    for n in range(num_blocks-1, -1, -1):
        if line_point[n] > -500:
            move_turn = (move_turn + (line_point[n])) / 2
        else:
            line_none += 1

    #for rec in roi1:
    #    color_img.draw_rectangle(rec, color=(255, 0, 0))

    if line_none <= num_blocks-3:       #3及以上
        pass
    elif line_none == num_blocks-2:     #2
        move_x *= 2
        move_turn *= 2
    elif line_none == num_blocks-1:     #1
        move_x *= 3
        move_turn *= 3

    if line_none < num_blocks:
        stop_count = 0
        print(move_x, move_turn, flag)
        outuart(move_x, move_turn, flag)
    else:
        stop_count += 1
        if stop_count > 20:
            outuart(0, 0, 2)

    #print(clock.fps())
